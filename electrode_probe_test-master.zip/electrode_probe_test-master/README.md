__This repository includes all the items of the TO-DO list I was asked for,__


**meanvar.ipynb File**
This file uses Numba to optimize the loops.
numpy.array(), time vector, and convolution were some of the parameters used in this file. The file is able to be called in less then a second.

**intan_rhd_file.ipynb**
This fie includes part 1 of the TO-DO list 'Intan Recording System'

